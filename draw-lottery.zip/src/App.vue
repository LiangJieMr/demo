<template>
	<div id="app">
		<router-view/>
	</div>
</template>

<script>
	export default {
		name: 'App'
	}
</script>

<style>
	html,
	body {
		height: 100%;
		position: relative;
		overflow: hidden;
		over-flow: auto;
		-webkit-overflow-scrolling: touch;
	}
	
	#app {
		height: 100%;
		font-family: 'Avenir', Helvetica, Arial, sans-serif;
		-webkit-font-smoothing: antialiased;
		-moz-osx-font-smoothing: grayscale;
		text-align: center;
		color: #2c3e50;
	}
	/*弹窗动画--开始*/
	
	.alert-out-enter,
	.alert-out-leave-active {
		opacity: 0;
	}
	
	.alert-out-leave-active,
	.alert-out-enter-active {
		transition: opacity 300ms;
	}
	
	.alert-content-enter-active,
	.alert-content-leave-active {
		opacity: 1;
		transition-duration: 400ms;
		transform: translate(-50%, -50%) scale(1)!important;
		transition-property: transform, opacity!important;
	}
	
	.alert-content-leave-active {
		transition-duration: 300ms;
	}
	
	.alert-content-enter {
		opacity: 0;
		transform: translate(-50%, -50%) scale(1.185)!important;
	}
	
	.alert-content-leave-active {
		opacity: 0;
		transform: translate(-50%, -50%) scale(0.85)!important;
	}
	/*弹窗动画--结束*/
	
	.hairlines .div-1px {
		border: .5px solid #fff !important;
	}
</style>