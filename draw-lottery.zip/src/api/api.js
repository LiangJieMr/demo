//alert(window.location.host)
export default{
	sendsms:"/api/user/sendsms",//登录注册发送验证码
	codelogin: "/api/user/codelogin", // 验证码登录接口
	all_record:"/api/all_record",
	turnplate_raffle:"/api/turnplate_raffle",
	userprize:"/api/user/userprize"
}

