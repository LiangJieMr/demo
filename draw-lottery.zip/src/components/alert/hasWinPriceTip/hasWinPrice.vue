<template>
	<div class="has_win_price">
		<transition name="alert-out">
			<mask-box v-show="priceAlert == 1"></mask-box>
		</transition>
		<transition name="alert-content">
			<div class="box" v-show="priceAlert == 1">
				<p class="title">
					已经抽过奖啦
				</p>
				<p class="infor">
					您已抽中：
					<br />
					<span v-if="priceType == 1">
							一等奖&nbsp;iPhone X手机一部！
					</span>
					<span v-if="priceType == 2">
							二等奖&nbsp;首次学费全免！
					</span>
					<span v-if="priceType == 3">
							三等奖&nbsp;50元现金红包！
					</span>
				</p>
				<p class="price">
					<img v-if="priceType == 1" src="../../img/priceOne.png"/>
					<img v-if="priceType == 2" src="../../img/priceTwo.png"/>
					<img v-if="priceType == 3" src="../../img/priceThree.png"/>
				</p>
				<close-btn @closeAlert="closeAlert"></close-btn>
				<code-part></code-part>
			</div>
		</transition>
	</div>
</template>

<script>
	import MaskBox from '../../common/mask/mask';
	import CloseBtn from '../../common/close/close';
	import CodePart from '../../common/code/code';
	export default{
		data(){
			return {
				
			}
		},
		props:['priceAlert','priceType'],
		components:{
			MaskBox,
			CloseBtn,
			CodePart
		},
		methods:{
			closeAlert(){
				this.$emit('closeAlert')
			}
		}
	}
</script>

<style lang="scss" scoped>
	@import './hasWinPrice';
</style>