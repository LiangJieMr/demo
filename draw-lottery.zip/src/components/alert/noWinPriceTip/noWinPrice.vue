<template>
	<div class="no_win_price">
		<transition name='alert-out'>
			<mask-box v-show="priceAlert == 2"></mask-box>
		</transition>
		<transition name='alert-content'>
			<div class="box" v-show="priceAlert == 2">
				<no-right></no-right>
				<close-btn @closeAlert="closeAlert"></close-btn>
			</div>
		</transition>
	</div>
</template>

<script>
	import CloseBtn from '../../common/close/close';
	import MaskBox from '../../common/mask/mask';
	import NoRight from '../../common/noRight/noRight';
	export default{
		data(){
			return {
				
			}
		},
		methods:{
			closeAlert(){
				this.$emit('closeAlert')
			}
		},
		props:['priceAlert'],
		components:{
			MaskBox,
			NoRight,
			CloseBtn
		}
	}
</script>

<style lang="scss" scoped>
	@import './noWinPrice';
</style>