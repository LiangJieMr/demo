<template>
	<div class="win_price_tip">
		<transition name='alert-out'>
			<mask-box v-show="priceAlert == 3"></mask-box>
		</transition>
		<transition name='alert-content'>
			<div class="main"  v-show="priceAlert == 3">
				<div class="box">
				</div>
				<div class="container">
					<p class="align_center title">
						恭喜您抽中：
					</p>
					<p class="align_center price">
						<span v-if="priceType == 1">
							一等奖：iPhone X手机一部！
						</span>
						<span v-if="priceType == 2">
							二等奖：首次学费全免！
						</span>
						<span v-if="priceType == 3">
							三等奖：50元现金红包！
						</span>
					</p>
					<p ref="priceBox" class="price_img">
						<img v-if="priceType == 1" src="../../img/priceOne.png"/>
						<img v-if="priceType == 2" src="../../img/priceTwo.png"/>
						<img v-if="priceType == 3" src="../../img/priceThree.png"/>
					</p>
				</div>
				<div class="container_mask">
					<close-btn @closeAlert="closeAlert"></close-btn>
					<code-part></code-part>
				</div>
			</div>
		</transition>
	</div>
</template>

<script>
	import MaskBox from '../../common/mask/mask';
	import CodePart from '../../common/code/code';
	import CloseBtn from '../../common/close/close';
	export default {
		data() {
			return {
				
			}
		},
		props:['priceAlert','priceType'],
		mounted() {

		},
		components:{
			MaskBox,
			CodePart,
			CloseBtn
		},
		methods: {
			closeAlert(){
				this.$emit('closeAlert',1)
			}
		}
	}
</script>

<style lang="scss" scoped>
	@import './winPriceTip';
</style>