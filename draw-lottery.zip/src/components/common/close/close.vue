<template>
	<img @click="closeAlert"  class="close" src="../../img/close.png" />
</template>

<script>
	export default{
		methods:{
			closeAlert(){
				console.log('执行')
				this.$emit('closeAlert');
			}
		}
	}
</script>

<style lang="scss" scoped>
@import './close'
</style>