<template>
	<p class="code_infor">
		<img src="../../img/code.png" />
		<span>
			长按二维码添加工作人员
			<br />
			完成奖项兑换！
		</span>
	</p>
</template>

<script>
</script>

<style lang="scss" scoped>
	@import 'code';
</style>