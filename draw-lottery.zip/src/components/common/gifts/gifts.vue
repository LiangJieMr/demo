<template>
	<ul>
		<li v-for="item in gift" :style="{transform:'rotate('+item.angles+'deg)'}">
			<span :style="{backgroundImage:'url(../../img/'+item.pic+'.png)'}">
				
			</span>
		</li>
	</ul>
</template>

<script>
	export default {
		props: {
			gift: Array,
		}
	}
</script>

<style>

</style>