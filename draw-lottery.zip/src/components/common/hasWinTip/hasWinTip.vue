<template>
	<div class="has_win_tip">
		<p class="title">
			抽过奖啦，您已获得&nbsp;:
		</p>
		<p class="price">
			<span v-if="priceType == 1">
				一等奖：iPhone X手机一部！
			</span>
			<span v-if="priceType == 2">
				二等奖：首次学费全免！
			</span>
			<span v-if="priceType == 3">
				三等奖：50元现金红包！
			</span>
		</p>
		<p class="price_img">
			<img v-if="priceType == 1" src="../../img/priceOne.png" />
			<img v-if="priceType == 2" src="../../img/priceTwo.png" />
			<img v-if="priceType == 3" src="../../img/priceThree.png" />
		</p>
		<p class="code">
			<img src="../../img/code1.png" />
			<span>
				请长按二维码添加工作人员兑奖
			</span>
		</p>
	</div>
</template>

<script>
	export default {
		props: ['priceType']
	}
</script>

<style lang="scss" scoped>
	@import './hasWinTip'
</style>