<template>
	<div class="mask">
		
	</div>
</template>

<script>
</script>

<style lang="scss" scoped>
@import './mask'
</style>