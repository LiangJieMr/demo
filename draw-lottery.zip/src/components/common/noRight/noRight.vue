<template>
	<div class="no_right">
		<img class="con" src="../../img/noRight.png"/>
		<img @click="goPage" class="btn" src="../../img/noRightBtn.png"/>
	</div>
</template>

<script>
	export default{
		methods:{
			goPage(){
				window.location.href = "http://" + window.location.host + '/dist/subjectChannel';
			}
		}
	}
</script>

<style lang="scss" scoped>
@import './noRight';
</style>