<template>
	<div>
		<!--<span class="coud_num">5</span>-->
		<div id="zhuanpan">
			<img ref="img" class="rotary-table" src="../../img/zhuanpan-bg.png">
			<a :class="{disabled:disabled,active:active,noActive:!active}" href="javascript:;" @touchstart="start" @touchend="goResult" ref="pointer" class="point"></a>
		</div>
		<!--<p class="result"></p>-->

	</div>
</template>

<script>
	import API from 'api/api';
	import axios from 'axios';
	import Qs from 'qs';
	export default {
		data() {
			return {
				config: {
					rotateAngle: 0,
					flag: true,
					data: [{
							a: 0,
							p: 0.1,
							t: 1
						},
						{
							a: 60,
							p: 0.1,
							t: 3
						},
						{
							a: 120,
							p: 0.1,
							t: 2
						},
						{
							a: 180,
							p: 0.1,
							t: 3
						},
						{
							a: 240,
							p: 0.1,
							t: 2
						},
						{
							a: 300,
							p: 0.1,
							t: 3
						}
					],
					type: 0,
					during: 3,
				},
				disabled:false,
				active:false
			}
		},
		mounted() {

		},
		components: {
			//			HasWinPriceTip,
			//			NoWinPriceTip
			//			WinPriceTip
		},
		methods: {
			start(){
				this.active = true;
			},
			over(){
				
			},
			goResult() {
				this.active = false;
				if(this.config.flag) {
					const {
						userSign
					} = this.$route.query;
					
					const that = this;
					const config = {
						method: 'post',
						url: API.turnplate_raffle,
						data: {
							user_sign: userSign
						},
						transformRequest: [function(data) {
							that.disabled = true;
							data = Qs.stringify(data);
							return data;
						}]
					};
					
					axios(config)
						.then(function(res) {
							that.disabled = false;
							const {
								status,
								msg,
								record_log
							} = res.data;

							//1：成功抽奖，
							//2：以前已经抽奖，
							//3：抽奖失败
							//4：用户密钥过期
							//5：用户没有资格抽奖
							//6：用户未登录
							if(status == 1) {
								that.result(record_log);
							} else if(status == 2) {
								that.$emit('dealLottery', 2,record_log);
							} else if(status == 3) {
								that.$emit('dealLottery', 3,msg);
							} else if(status == 4) {
								that.$emit('dealLottery', 4,msg);
							} else if(status == 5) {
								that.$emit('dealLottery', 5);
							} else if(status == 6) {
								that.$emit('dealLottery', 6,msg);
							}
							else{
								that.$emit('dealLottery', 7,msg);
							}
						})
						.catch(function(err) {
								that.disabled = false;
								that.$emit('dealLottery', 7,'接口报错！');
						})
				}
			},
			callback(num) {
				this.$emit('dealLottery',1,num);
			},
			setStyle(ele, rotate, during) {
				ele.style.cssText = `transform: rotate(${rotate}deg);
					-ms-transform: rotate(${rotate}deg);
					-webkit-transform: rotate(${rotate}deg);
					-moz-transform: rotate(${rotate}deg);
					-o-transform: rotate(${rotate}deg);
					transition: transform ease-out ${during}s;
					-moz-transition: -moz-transform ease-out ${during} s;
					-webkit-transition: -webkit-transform ease-out ${during} s;
					-o-transition: -o-transform ease-out ${during} s;`
			},
			randomFrom(lowerValue,upperValue){
			 return Math.floor(Math.random() * (upperValue - lowerValue + 1) + lowerValue);
			},
			result(priceNum) {

				/*
				 *randNum：用来判断的随机数，1-100
				 *resultIndex：最终要旋转到哪一块，对应this.config.data的下标
				 *startPos:判断的角度值起始位置
				 *endPos:判断的角度值结束位置
				 *randCircle：// 附加多转几圈，2-3
				 */
				let randNum;
				const priceTwo = [3,5];
				const priceThree = [2,4,6];
				switch(priceNum){
					case '1':
					randNum = 1;
					break;
					case '2':
					randNum = priceTwo[this.randomFrom(0,1)];
					break;
					case '3':
					randNum = priceThree[this.randomFrom(0,2)];
					break;
				}
				const {
					data,
					rotateAngle,
					type,
					during
				} = this.config;
				let resultIndex = 1;
				let startPos = 0;
				let endPos = 0;
				const randCircle = Math.ceil(Math.random() * 2) + 1;
				
				// 旋转结束前，不允许再次触发
				this.config.flag = false;

				for(let i in data) {
					startPos = endPos + 1; // 区块的起始值
					endPos = endPos + 10 * data[i].p; // 区块的结束值
					if(randNum >= startPos && randNum <= endPos) { // 如果随机数落在当前区块，那么获取到最终要旋转到哪一块
						resultIndex = i;
						break;
					}
				};
				switch(type) {
					case 0:
						this.config.rotateAngle = rotateAngle + randCircle * 360 + data[resultIndex].a - rotateAngle % 360;
						this.setStyle(this.$refs.img, this.config.rotateAngle, during);
						break;
					case 1:
						this.config.rotateAngle = rotateAngle - randCircle * 360 - data[resultIndex].a - rotateAngle % 360;
						this.setStyle(this.$refs.pointer, this.config.rotateAngle, during);
						break;
				};
				// 旋转结束后，允许再次触发
				const _this = this;
				setTimeout(function() {
					_this.config.flag = true;
					// 告诉结果
					if(data[resultIndex].t && randNum) {
						_this.callback(data[resultIndex].t);
					}
				}, during * 1000);
			}
		}
	}
</script>

<style lang="scss" scoped>
	@import './pan';
</style>