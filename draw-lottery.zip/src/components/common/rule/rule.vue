<template>
	<div class="rule">
		<div class="title">
			<img src="../../img/rule.png" />
			<strong>活动规则</strong>
		</div>
		<div class="rule_content">
			<p>
				1、温馨提示：
				<br/> (1)本活动仅对4月15日后，通过“奥鹏教育”微信公众号进入网络招生平台在线报名、缴费的新学员有效；
				<br/> (2)报名学员预留电话确保准确，如果不一致，导致奖品不能发放或延迟发放，学员自行承担；
				<br/> (3)本次活动由“奥鹏教育”网络招生平台发起，所有奖项真实有效；
				<br/> (4)本次活动官方咨询电话：4008-131-121 官方微信：open658
			</p>
		</div>
	</div>
</template>

<script>
</script>

<style lang="scss" scoped>
	@import './rule';
</style>