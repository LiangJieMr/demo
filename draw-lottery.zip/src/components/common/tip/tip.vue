<template>
	<div class="tip">
		<p>恭喜您已报名缴费成功，获得抽奖机会！
			<br />
			 请点击上方“ 
			<span>点击抽奖</span>”抽取奖品！
		</p>
	</div>
</template>

<script>
	
</script>

<style lang="scss" scoped>
	@import './tip';
</style>