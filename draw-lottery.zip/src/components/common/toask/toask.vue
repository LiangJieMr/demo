<template>
	<div class="toask">
		<transition name="alert-out">
			<div class="box" v-show="toaskFlage">
				{{text}}
			</div>
		</transition>
	</div>
</template>

<script>
	export default {
		data(){
			return {
				toaskFlage:false
			}
		},
		props:['showTosk','text'],
		watch: {
			showTosk(curVal,oldVal) {
				console.log(curVal,oldVal);
				if(curVal) {
					const that = this;
					that.toaskFlage = true;
					const timer = setTimeout(function() {
						that.toaskFlage = false;
						that.$emit('closeTosk');
						clearTimeout(timer);
					},2500)
				}
				else{
					
				}
			}
		}
	}
</script>

<style lang="scss" scoped>
	@import 'toask';
</style>