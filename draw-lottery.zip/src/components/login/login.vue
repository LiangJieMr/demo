<template>
	<div class="main" >
		<transition name="alert-out">
			<mask-box v-show="showLogin"></mask-box>
		</transition>
		<transition name="alert-content">
			<div class="bomb_box" v-show="showLogin">
				<div class="open_login">
					<img class="login" src="../img/logo111111-01.png" />
				</div>
				<div class="userInfor">
					<form @submit.prevent>
						<div class="phone">
							<input type="text" placeholder="请输入您的手机号码,进行抽奖" @blur="checkNumber(phoneNum)" maxlength="11" v-model="phoneNum" />
							<button :disabled="timerDisabled ? true:false" @click="timer">
						{{verificationCode}}
					</button>
						</div>
						<div class="code">
							<input type="text" placeholder="请输入验证码" maxlength="4" @blur="checkCode(msgCode)" v-model="msgCode" />
						</div>
						<div class="propt">
							{{errorMsg}}
						</div>
						<div class="opt">
							<button :disabled="calcDisabled ? false:true" @click="participateIn" :class="calcDisabled ? '': 'disabled'">
						立即参与
					</button>
						</div>
					</form>
				</div>
			</div>
		</transition>
	</div>
</template>

<script>
	import MaskBox from '../common/mask/mask';
	import {setStore} from 'lib/mUntil/mUtils';
	import API from 'api/api';
	import axios from 'axios';
	import Qs from 'qs';
	export default {
		data() {
			return {
				verificationCode: '获取验证码',
				timerDisabled: false,
				phoneFlage: false,
				codeFlage: false,
				errorMsg: '',
				phoneNum: '',
				msgCode: ''
			}
		},
		props:['showLogin'],
		components:{
			MaskBox
		},
		methods: {
			checkNumber: function(val) {
				if(val.replace(/(^\s*)|(\s*$)/g, "").length == 0) {
					this.phoneFlage = false;
					this.errorMsg = "手机号码不能为空！";
				} else if(!(/^1[3456789]\d{9}$/).test(val)) {
					this.phoneFlage = false;
					this.errorMsg = "手机号码格式不正确！";
				} else {
					this.phoneFlage = true;
					this.errorMsg = "";

				}
			},
			checkCode: function(val) {
				if(val.replace(/(^\s*)|(\s*$)/g, "").length == 0) {
					this.codeFlage = false;
					this.errorMsg = "验证码不能为空！";
				} else if(val.length < 4) {
					this.codeFlage = false;
					this.errorMsg = "验证码为4个字符";
				} else if(val.length > 4) {
					this.codeFlage = false;
					this.errorMsg = "验证码最长不能超过4个字符";
				} else {
					this.codeFlage = true;
					this.errorMsg = "";
				}
			},
			participateIn: function() {
				const config = {
					method: 'post',
					url: API.codelogin,
					data: {
						phone: this.phoneNum,
						sms_code: this.msgCode
					},
					transformRequest: [function(data) {
						data = Qs.stringify(data);
						return data;
					}]
				};
				const that = this;
				axios(config)
					.then(function(res) {
						const {
							code,
							data,
							msg
						} = res.data;
						if(code == 200) {
							const curPath = that.$route.query.path;
							setStore('infor', {
								user_sign:data.user_sign,
								phone_num: that.phoneNum
							});
							that.$router.replace({
								path: curPath,
								query:{userSign:data.user_sign}
							});
							that.$emit('closeLogin');
						} else {
							that.$emit("showToaskFunc",msg);
						}
					})
					.catch(function(err) {
						that.$emit("showToaskFunc","接口报错！");
					})
			},
			setTime: function() {
				let time = 59;
				this.timerDisabled = true;
				this.verificationCode = time + '(s)';
				const that = this;
				const timer = setInterval(function() {
					time--;
					that.verificationCode = time + '(s)';
					if(time <= 0) {
						that.verificationCode = "获取验证码";
						that.timerDisabled = false;
						clearInterval(timer);
					}
				}, 1000)
			},
			timer: function() {
				this.checkNumber(this.phoneNum);
				if(this.phoneFlage) {
					const that = this;
					const config = {
						method: 'post',
						url: API.sendsms,
						data: {
							phone: this.phoneNum,
							type: 1,
							deviceInfo:_fmOpt.getinfo()
						},
						transformRequest: [function(data) {　　
							data = Qs.stringify(data);
							that.timerDisabled = true;
							return data;
						}]
					};

					axios(config)
						.then(function(res) {
							const {
								code,
								msg,
								data
							} = res.data;
							if(code == 1) {
								that.$emit("showToaskFunc",msg);
								that.setTime();
							} else {
								that.timerDisabled = false;
								that.$emit("showToaskFunc",msg);
							}
						})
						.catch(function(err) {
							that.timerDisabled = false;
							that.$emit("showToaskFunc","接口报错");;
						});
				}
			}
		},
		computed: {
			calcDisabled: function() {
				return this.phoneFlage && this.codeFlage;
			}
		},
		watch: {
			phoneNum: function(curVal) {
				this.checkNumber(curVal);
			},
			msgCode: function(curVal) {
				this.checkCode(curVal);
			}
		}
	}
</script>

<style lang="scss" scoped>
	@import './login';
</style>