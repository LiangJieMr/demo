<template>
	<div class="lattery_box">
		<div class="box-size">
			<div class="top">
				<img src="../img/top.png" />
			</div>
			<div class="tishi" ref="scroll_content">
				<ul>
					<li :key="item.id" v-for="item in slideArray">
						{{"恭喜：" + (item.name ? item.name :'') + "&nbsp;" + (item.phone ? item.phone :'') + "&nbsp;&nbsp;" + (item.info ? item.info:'')}}
					</li>
				</ul>
			</div>
			<div class="lottery">
				<pan @dealLottery="dealLottery" v-if="priceTip != 1"></pan>
			</div>
			<div class="propt">
				<has-win-tip :priceType="priceType" v-if="priceTip == 1"></has-win-tip>
				<tip v-if='priceTip == 2'></tip>
				<no-right v-if='priceTip == 3'></no-right>
			</div>
			<rule></rule>
		</div>

		<login @showToaskFunc="showToaskFunc" @closeLogin="closeLogin" :showLogin='showLogin'></login>

		<has-win-price-tip @closeAlert="closeAlert" :priceType="priceType" :priceAlert="priceAlert"></has-win-price-tip>
		<no-win-price-tip @closeAlert="closeAlert" :priceAlert="priceAlert"></no-win-price-tip>
		<win-price-tip @closeAlert='closeAlert' :priceType="priceType" :priceAlert="priceAlert"></win-price-tip>

		<toask :showTosk='showTosk' @closeTosk='closeTosk' :text='text'></toask>
	</div>
</template>
<script>
	import Login from '../login/login';
	import Tip from '../common/tip/tip';
	import NoRight from '../common/noRight/noRight';
	import Rule from '../common/rule/rule';
	import Pan from '../common/pan/pan';
	import HasWinTip from '../common/hasWinTip/hasWinTip';

	import HasWinPriceTip from '../alert/hasWinPriceTip/hasWinPrice';
	import NoWinPriceTip from '../alert/noWinPriceTip/noWinPrice';
	import WinPriceTip from '../alert/winPriceTip/winPriceTip';

	import Toask from '../common/toask/toask';

	import API from 'api/api';
	import axios from 'axios';
	import Qs from 'qs';
	export default {
		data() {
			return {
				slideArray: [{
					name: ''
				}],
				MyMar: null,
				showLogin: false,
				priceTip: 0,
				priceAlert: 0,
				priceType: 0,
				showTosk: false,
				text: ''
			}
		},
		mounted() {
			this.getParam();
			this.getPrice();
		},
		methods: {
			showToaskFunc(text) {
				this.showTosk = true;
				this.text = text;
			},
			getParam() {
				const {
					userSign
				} = this.$route.query;
				this.judgeUser(userSign);
			},
			getPrice() {
				const config = {
					method: 'get',
					url: API.all_record,
					data: {},
					transformRequest: [function(data) {
						data = Qs.stringify(data);
						return data;
					}]
				};
				const that = this;
				axios(config)
					.then(function(res) {
						const {
							status,
							msg,
							data
						} = res.data;
						if(status == 1) {
							that.slideArray = data;
							that.slideScroll(data);
						} else {
							that.slideArray = [];
							that.showToaskFunc(msg);
						}
					})
					.catch(function(err) {
						that.showToaskFunc('接口报错！');
					})
			},
			judgeUser(userSign) {
				if(userSign) {
					this.showLogin = false;
					this.judgeStatus(userSign);
				} else {
					this.showLogin = true;
				}
			},
			judgeStatus(userSign) {
				const config = {
					method: 'post',
					url: API.userprize,
					data: {
						user_sign: userSign
					},
					transformRequest: [function(data) {
						data = Qs.stringify(data);
						return data;
					}]
				};
				const that = this;
				axios(config)
					.then(function(res) {
						const {
							code,
							msg,
							data
						} = res.data;
						if(code == 200) { //有抽奖机会
							that.priceTip = 2;
						} else if(code == -1) { //没权限
							that.priceTip = 3;
						} else if(code == -2) { //已抽过
							that.priceTip = 1;
							that.priceType = data;
						} else if(code == 201) { //过期
							that.showToaskFunc(msg);
							const curPath = that.$route.query.path;
							that.$router.replace({
								path: curPath
							});
							that.showLogin = true;
						}
						else{
							that.showToaskFunc(msg);
							that.priceTip = 0;
						}
					})
					.catch(function(err) {
						that.showToaskFunc('接口报错！')
					})
			},
			slideScroll() {
				const scrollArea = this.$refs.scroll_content;
				const li = scrollArea.getElementsByTagName("li")[0];
				const liHeight = li ? li.offsetHeight : 0;
				const that = this;

				function Marquee() {
					const scrollTopVal = Math.ceil(scrollArea.scrollTop + 1);
					if(scrollTopVal >= liHeight) {
						scrollArea.scrollTop = 0;
						const saveData = that.slideArray.shift();
						that.slideArray.push(saveData);
					} else {
						scrollArea.scrollTop = scrollArea.scrollTop + 1;
					}
				}
				if(li) {
					setInterval(Marquee, 40);
				}
			},
			closeLogin() {
				this.showLogin = false;
				this.getParam();
			},
			closeAlert(type) {
				if(type == 1) {
					this.getPrice();
					this.priceTip = 1;
					//					this.judgeUser();
				}
				this.priceAlert = 0;
			},
			closeTosk() {
				this.showTosk = false;
			},
			dealLottery(status, type) {
				switch(status) {
					case 1:
						this.priceAlert = 3;
						this.priceType = type;
						break;
					case 2:
						this.priceAlert = 1;
						this.priceType = type;
						this.priceTip = 1;
						break;
					case 3:
						this.showToaskFunc(type);
						this.priceType = 0;
						this.priceTip = 0;
						break;
					case 4:
						this.showToaskFunc(type);
						const curPath1 = this.$route.query.path;
						this.$router.replace({
							path: curPath1
						});
						this.showLogin = true;
						break;
					case 5:
						this.priceAlert = 2;
						this.priceTip = 3;
						break;
					case 6:
						this.showToaskFunc(type);
						const curPath2 = this.$route.query.path;
						this.$router.replace({
							path: curPath2
						});
						this.showLogin = true;
						break;
					case 7:
						this.showToaskFunc(type);
						break;
				}
			}
		},
		components: {
			Login,
			Tip,
			NoRight,
			Rule,
			Pan,
			HasWinTip,
			HasWinPriceTip,
			NoWinPriceTip,
			WinPriceTip,
			Toask
		}
	}
</script>
<style lang="scss" scoped>
	@import './lottery';
</style>