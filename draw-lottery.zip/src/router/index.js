import Vue from 'vue'
import Router from 'vue-router'
Vue.use(Router)

const Lottery = (resolve) => {
	import('@/components/lottery/lottery').then((module) => {
	    resolve(module)
	})
}

const Login = (resolve) => {
	import('@/components/login/login').then((module) => {
	    resolve(module)
	})
}

const Pan = (resolve) => {
	import('@/components/common/pan/pan').then((module) => {
	    resolve(module)
	})
}

const WinPriceTip = (resolve) => {
	import('@/components/alert/winPriceTip/winPriceTip').then((module) => {
	    resolve(module)
	})
}

const HasWinPriceTip = (resolve) => {
	import('@/components/alert/hasWinPriceTip/hasWinPrice').then((module) => {
	    resolve(module)
	})
}

const NoWinPriceTip = (resolve) => {
	import('@/components/alert/noWinPriceTip/noWinPrice').then((module) => {
	    resolve(module)
	})
}
const HasWinTip = (resolve) => {
	import('@/components/common/hasWinTip/hasWinTip').then((module) => {
	    resolve(module)
	})
}
const Toask = (resolve) => {
	import('@/components/common/toask/toask').then((module) => {
	    resolve(module)
	})
}
export default new Router({
//mode:"history",
//base: '/lottery/',
  routes: [
     // 根路径重定向
    {
      path: '/',
      redirect: '/index',
      component: Lottery
    },
     //首页
     {
     	path:'/index',
     	component:Lottery
     },
     //登录
    {
    	path:'/login',
    	component:Login
    },
    //抽中奖
    {
    	path:'/winPriceTip',
    	component:WinPriceTip
    },
     //已经抽中奖
    {
    	path:'/hasWinPriceTip',
    	component:HasWinPriceTip
    },
    //没有资格
    {
    	path:'/noWinPriceTip',
    	component:NoWinPriceTip
    },
     //转盘
    {
    	path:'/pan',
    	component:Pan
    },
     //转盘
    {
    	path:'/hasWinTip',
    	component:HasWinTip
    },
    {
    	path:'/toask',
    	component:Toask
    } 
  ]
})
