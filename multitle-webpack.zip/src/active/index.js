console.log('执行了')
import "./index.scss";
import "../core/header.scss";
